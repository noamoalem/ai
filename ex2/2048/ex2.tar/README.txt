208533554
315440966
*****
Comments:
In the better_evaluation_function we choose to return the current score and
the number of identical tiles in the same row / col/.